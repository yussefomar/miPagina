#ifndef DESACELERARJUGADOR_H
#define DESACELERARJUGADOR_H
#include <Command.h>
#include "Model.h"

class DesacelerarJugador: public Command
{
    public:
        DesacelerarJugador(Model* model);
        virtual ~DesacelerarJugador();
        void execute();

    protected:

    private:
         Model* model;
};

#endif // DESACELERARJUGADOR_H
