#include "DesacelerarJugador.h"
#include "Model_Jugador.h"

DesacelerarJugador::DesacelerarJugador(Model* model)
{
        this->model=model;
}

DesacelerarJugador::~DesacelerarJugador()
{
    //dtor
}

void DesacelerarJugador::execute()
{
    Jugador* jugador = this->model->getJugadorActivo();
    jugador->desacelerarJugador();
    return;
}
