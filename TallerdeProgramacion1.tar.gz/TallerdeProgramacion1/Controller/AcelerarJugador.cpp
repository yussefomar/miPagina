#include "AcelerarJugador.h"
#include "Model_Jugador.h"

AcelerarJugador::AcelerarJugador(Model* model)
{
    this->model=model;
}

AcelerarJugador::~AcelerarJugador()
{

}

void AcelerarJugador::execute()
{
    Jugador* jugador = this->model->getJugadorActivo();
    jugador->acelerarJugador();
    return;
}
