#ifndef COMMAND_H
#define COMMAND_H

class Command
{
public:
    Command();
    virtual ~Command();
    virtual void execute() = 0;
    static const int VELOCIDAD = 6;
protected:

private:
};

#endif // COMMAND_H
