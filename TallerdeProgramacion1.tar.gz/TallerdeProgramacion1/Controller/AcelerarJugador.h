#ifndef ACELERARJUGADOR_H
#define ACELERARJUGADOR_H
#include <Command.h>
#include "Model.h"

class AcelerarJugador: public Command
{
    public:
        AcelerarJugador(Model* model);
        virtual ~AcelerarJugador();
        void execute();

    protected:

    private:
        Model* model;
};

#endif // ACELERARJUGADOR_H
