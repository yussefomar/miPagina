#include "Formacion.h"

Formacion::Formacion()
{
    //ctor
}

Formacion::~Formacion()
{
    //dtor
}
