#ifndef FORMACION312_H
#define FORMACION312_H

#include <Formacion.h>


class Formacion312 : public Formacion
{
    public:
        Formacion312();
        virtual ~Formacion312();
        void setPosicionInicial(Jugador* jugadores);

    protected:

    private:
};

#endif // FORMACION312_H
