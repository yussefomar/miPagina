#ifndef ESTADO_H
#define ESTADO_H
#include <stdio.h>

class Estado
{
public:
    Estado();
    virtual ~Estado();
    //Position accessors
    int getPosX();
    int getPosY();
    //Position accessors
    int getVelX();
    int getVelY();

    void setPosX(int PosX);
    void setPosY(int PosY);
    void setCorrer(bool corrio);
    bool getCorrer();

    void setPosInitX(int posX);
    void setPosInitY(int posY);
    void copiarEstado(Estado* estado);
    void disminuirVelocidadX();
    void disminuirVelocidadY();
    void aumentarVelocidadX();
    void aumentarVelocidadY();
    void acelerarJugador();
    void desacelerarJugador();

    virtual void move() = 0;

    virtual bool estaActivo() = 0;
    //virtual void stop() = 0;

protected:
    //The X and Y offsets of the dot
    int mPosX, mPosY;
    int posInitX, posInitY;
    //The velocity of the dot
    int mVelX, mVelY;
    int VELOCIDAD_JUGADOR ;
private:
};

#endif // ESTADO_H
