#ifndef FORMACION33_H
#define FORMACION33_H

#include <Formacion.h>


class Formacion33 : public Formacion
{
public:
    Formacion33();
    virtual ~Formacion33();
    void setPosicionInicial(Jugador* jugadores);


protected:

private:

};

#endif // FORMACION33_H
