#include "Observer.h"

Observer::Observer()
{
    //ctor
}

Observer::~Observer()
{
    //dtor
}
