#ifndef EVENT_H
#define EVENT_H


class Event
{
    public:
        Event();
        virtual ~Event();

    protected:

    private:
};

#endif // EVENT_H
